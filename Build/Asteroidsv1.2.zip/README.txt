--- Asteroids v1.2 ---

Made for Game Behaviour module.

- Controls -

left/right 	Rotate ship
space		Thrust
r		Restart game (when dead)
q		Quit Game

- Hint -

Enemy ship will get more powerful over time...
